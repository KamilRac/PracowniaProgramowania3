public class Motto
{
    public static void main(String[] args) {
	System.out.println("Do what you love");
}

}
