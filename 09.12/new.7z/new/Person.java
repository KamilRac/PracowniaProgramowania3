public class Person
{
    String name;
    int weight;
    int height;
    Person(String name){
    this.name = name;
    };
    public Person(String name, int weight, int height){
        this.name = name;
        this.weight = weight;
        this.height = height;
    };
    
    void setWeightAndHeight(int weight, int height){
        this.weight = weight;
        this.height = height;
    };
    
    double calculateBMI(){
    return (weight / (height/100.0) * (height/100.0));
    };
    
    void displayRecord(){
    System.out.println("Name: " + name);
    System.out.println("Weight: " + weight);
    System.out.println("Height: " + height);
    System.out.println("Name: " + name);
    };
    
}
