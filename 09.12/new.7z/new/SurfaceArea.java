public class SurfaceArea
{
    
    static double circleArea(double r){
     return 3.14*r*r; 
    };
    
    static double rectangleArea(double len, double wid){
    return len*wid;
    };
    
    static double triangleArea(double a, double h){
    return a*h/2;
    };
}
